﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizForm
{
    public partial class Q1 : Form
    {
        public Q1()
        {
            InitializeComponent();
        }
        int m = 1, s = 50;
        int duration = 109;
        System.Windows.Forms.Timer t;

        public static int score = 0;
        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {
            score = 1;

        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            score = 0;
        }
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            score = 0;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void Q1_Load(object sender, EventArgs e)
        {
            
            t = new System.Windows.Forms.Timer();            
            t.Interval = 1000;//1s
            t.Start();
            t.Tick += new EventHandler(count_down);
            
        }
        private void count_down(object sender, EventArgs e){
            if (s == 1)
            {
                m = 0;
                s += 59;
                
            }
            
            if (s > 0)
            {
                s--;
                duration--;
                timeTxt.Text = string.Format("{0} : {1}", m.ToString().PadLeft(2, '0'), s.ToString().PadLeft(2, '0'));
                //label1.Text = duration.ToString();
            }
            if (duration == 0)
            {
                t.Stop();
                this.Hide();

                Q2 que2 = new Q2();
                que2.ShowDialog();

                this.Close();

            }            
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            t.Stop();

            Q2 que2 = new Q2();
            que2.ShowDialog();

            this.Close();
        }
        
    }
}
