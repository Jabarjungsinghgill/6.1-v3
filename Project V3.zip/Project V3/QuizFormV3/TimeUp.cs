﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizForm
{
    public partial class TimeUp : Form
    {
        public TimeUp()
        {
            InitializeComponent();
        }

        private void TimeUp_Load(object sender, EventArgs e)
        {

        }
    }
}
