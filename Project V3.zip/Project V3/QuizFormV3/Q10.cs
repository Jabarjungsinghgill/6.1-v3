﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizForm
{
    public partial class Q10 : Form
    {
        public Q10()
        {
            InitializeComponent();
        }

        
        private void prevbtn_Click(object sender, EventArgs e)
        {
            this.Hide();

            Q9 que9 = new Q9();
            que9.ShowDialog();

            this.Close();
        }

        int m = 1, s = 50;
        int duration = 109;

        System.Windows.Forms.Timer t;
        private void Q10_Load(object sender, EventArgs e)
        {
            t = new System.Windows.Forms.Timer();
            t.Tick += new EventHandler(count_down);
            t.Interval = 1000;//1s
            t.Start();
        }

        public static int score = 0;
     


        private void endbtn_Click(object sender, EventArgs e)
        {
            //This button ends test and display sores.
            MessageBox.Show("This is the end of test");

        }

            string grade;
        private void endbtn_Click_1(object sender, EventArgs e)
        {
            int total_score = Q1.score + Q2.score + Q3.score + Q4.score + Q5.score + Q6.score + Q7.score + Q8.score + Q9.score + score;
            //This button ends test and display sores.
            this.Close();

            int gradeNum = total_score * 10;


            if (gradeNum >= 90)
            {
                grade = "A";
            }
            else if (gradeNum >= 80)
            {
                grade = "B";
            }
            else if (gradeNum >= 70)
            {
                grade = "C";
            }
            else if (gradeNum >= 60)
            {
                grade = "D";
            }
            else
            {
                grade = "F";
            }

            MessageBox.Show("Your grade for the quiz percentage is "+ total_score * 10+" -- "+grade);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            score = 0;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            score = 1;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            score = 0;
        }

        public void count_down(object sender, EventArgs e)
        {
            if (s == 1)
            {
                m = 0;
                s += 59;

            }
            if (s > 0)
            {
                s--;
                duration--;
                timeTxt.Text = string.Format("{0} : {1}", m.ToString().PadLeft(2, '0'), s.ToString().PadLeft(2, '0'));
                //label1.Text = duration.ToString();
            }
            if (duration == 0)
            {
                t.Stop();
                this.Hide();

                Q3 que3 = new Q3();
                que3.ShowDialog();

                this.Close();

            }

        }

    }
}
