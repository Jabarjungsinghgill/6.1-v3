﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizForm
{
    public partial class Q2 : Form
    {
        public Q2()
        {
            InitializeComponent();
        }
        int m = 1, s = 50;
        int duration = 109;
        System.Windows.Forms.Timer t;
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();

            Q3 que3 = new Q3();
            que3.ShowDialog();

            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Q1 que1 = new Q1();
            que1.ShowDialog();

            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Q2_Load(object sender, EventArgs e)
        {
            t = new System.Windows.Forms.Timer();
            t.Tick += new EventHandler(count_down);
            t.Interval = 1000;//1s
            t.Start();

        }
        public static int score = 0;
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            score = 1;

        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            score = 0;
        }
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            score = 0;
        }


        private void count_down(object sender, EventArgs e)
        {
            if (s == 1)
            {
                m = 0;
                s += 59;

            }
            if (s > 0)
            {
                s--;
                duration--;
                timeTxt.Text = string.Format("{0} : {1}", m.ToString().PadLeft(2, '0'), s.ToString().PadLeft(2, '0'));
                //label1.Text = duration.ToString();
            }
            if (duration == 0)
            {
                t.Stop();
                this.Hide();

                Q3 que3 = new Q3();
                que3.ShowDialog();

                this.Close();

            }

        }        
    }
}
