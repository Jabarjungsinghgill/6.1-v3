﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizForm
{
    public partial class Q5 : Form
    {
        public Q5()
        {
            InitializeComponent();
        }
        public static int score = 0;
        
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Q6 que6 = new Q6();
            que6.ShowDialog();

            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        
        int duration = 20;
        System.Windows.Forms.Timer t;
        private void Q5_Load(object sender, EventArgs e)
        {
            t = new System.Windows.Forms.Timer();
            t.Tick += new EventHandler(count_down);
            t.Interval = 1000;//1s
            t.Start();

        }
        private void count_down(object sender, EventArgs e)
        {
            
            if (duration > 0)
            {                
                duration--;
                timeTxt.Text = string.Format("00 : {0}", duration.ToString().PadLeft(2, '0'));
                //label1.Text = duration.ToString();
            }
            if (duration == 0)
            {
                t.Stop();
                this.Hide();

                TimeUp timeUpWin = new TimeUp();
                timeUpWin.ShowDialog();

                this.Close();

            }

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            score = 1;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            score = 0;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            score = 0;
        }
    }
}
