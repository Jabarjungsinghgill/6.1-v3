﻿namespace QuizForm
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.genlb = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.Label();
            this.usertxt = new System.Windows.Forms.TextBox();
            this.passtxt = new System.Windows.Forms.TextBox();
            this.logbtn = new System.Windows.Forms.Button();
            this.Xlbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // genlb
            // 
            this.genlb.AutoSize = true;
            this.genlb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genlb.Location = new System.Drawing.Point(172, 14);
            this.genlb.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.genlb.Name = "genlb";
            this.genlb.Size = new System.Drawing.Size(104, 17);
            this.genlb.TabIndex = 0;
            this.genlb.Text = "General Quiz";
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username.Location = new System.Drawing.Point(29, 63);
            this.username.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(75, 15);
            this.username.TabIndex = 1;
            this.username.Text = "UserName";
            // 
            // password
            // 
            this.password.AutoSize = true;
            this.password.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password.Location = new System.Drawing.Point(33, 91);
            this.password.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(69, 15);
            this.password.TabIndex = 2;
            this.password.Text = "Password";
            // 
            // usertxt
            // 
            this.usertxt.Location = new System.Drawing.Point(137, 63);
            this.usertxt.Margin = new System.Windows.Forms.Padding(2);
            this.usertxt.Name = "usertxt";
            this.usertxt.Size = new System.Drawing.Size(244, 20);
            this.usertxt.TabIndex = 3;
            this.usertxt.TextChanged += new System.EventHandler(this.usertxt_TextChanged);
            // 
            // passtxt
            // 
            this.passtxt.Location = new System.Drawing.Point(137, 91);
            this.passtxt.Margin = new System.Windows.Forms.Padding(2);
            this.passtxt.Name = "passtxt";
            this.passtxt.Size = new System.Drawing.Size(244, 20);
            this.passtxt.TabIndex = 4;
            this.passtxt.TextChanged += new System.EventHandler(this.passtxt_TextChanged);
            // 
            // logbtn
            // 
            this.logbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logbtn.Location = new System.Drawing.Point(161, 156);
            this.logbtn.Margin = new System.Windows.Forms.Padding(2);
            this.logbtn.Name = "logbtn";
            this.logbtn.Size = new System.Drawing.Size(191, 32);
            this.logbtn.TabIndex = 5;
            this.logbtn.Text = "Login";
            this.logbtn.UseVisualStyleBackColor = true;
            // 
            // Xlbl
            // 
            this.Xlbl.AutoSize = true;
            this.Xlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Xlbl.Location = new System.Drawing.Point(507, 6);
            this.Xlbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Xlbl.Name = "Xlbl";
            this.Xlbl.Size = new System.Drawing.Size(18, 17);
            this.Xlbl.TabIndex = 6;
            this.Xlbl.Text = "X";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.Xlbl);
            this.Controls.Add(this.logbtn);
            this.Controls.Add(this.passtxt);
            this.Controls.Add(this.usertxt);
            this.Controls.Add(this.password);
            this.Controls.Add(this.username);
            this.Controls.Add(this.genlb);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Login";
            this.Text = "Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label genlb;
        private System.Windows.Forms.Label username;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.TextBox usertxt;
        private System.Windows.Forms.TextBox passtxt;
        private System.Windows.Forms.Button logbtn;
        private System.Windows.Forms.Label Xlbl;
    }
}