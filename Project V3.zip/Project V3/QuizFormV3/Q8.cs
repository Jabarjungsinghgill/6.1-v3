﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizForm
{
    public partial class Q8 : Form
    {
        public Q8()
        {
            InitializeComponent();
        }
        public static int score = 0;
       


        private void nextbtn_Click(object sender, EventArgs e)
        {

            this.Hide();

            Q9 que9 = new Q9();
            que9.ShowDialog();

            this.Close();
        }

        int m = 1, s = 50;
        int duration = 109;

        System.Windows.Forms.Timer t;
        private void Q8_Load(object sender, EventArgs e)
        {
            t = new System.Windows.Forms.Timer();
            t.Tick += new EventHandler(count_down);
            t.Interval = 1000;//1s
            t.Start();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            score = 0;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            score = 1;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            score = 0;
        }

        public void count_down(object sender, EventArgs e)
        {
            if (s == 1)
            {
                m = 0;
                s += 59;

            }
            if (s > 0)
            {
                s--;
                duration--;
                timeTxt.Text = string.Format("{0} : {1}", m.ToString().PadLeft(2, '0'), s.ToString().PadLeft(2, '0'));
                //label1.Text = duration.ToString();
            }
            if (duration == 0)
            {
                t.Stop();
                this.Hide();

                Q3 que3 = new Q3();
                que3.ShowDialog();

                this.Close();

            }

        }

    }
}
